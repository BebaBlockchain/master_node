import express from 'express';
import bodyParser from 'body-parser';
const request = require('request');
import { SHA256 } from 'crypto-js';
const { HTTP_PORT = 3000 } = process.env;
const app = express();


// ************ VARIABLES DINAMICAS (NODO CONFIGURACION) ****************
const blockchain_domain = "https://blockexplorer.club";
const cryptocoin = "Bebacoin";
const port = 3000;
const user_node = "EXAMPLE Exchange";
var connection = "Desconectado...";
const ident = "T3ST455555ID3NT";
const api_key = "M4ST3RK3Y00000001";
const wallet_nodo = "048e39f64d96002267c5ec5db15eaa2037ee81dad353ac51eef32d89f88493b12b42d26f84db2a91e5989c25e7f5a4d175cc5f75b34dd18f510c839f959a87fb88";
// *********** FIN CONFIGURACION NODO ***********************************



app.use(bodyParser.json());

// ************ RUTAS SERVICIOS MASTER NODO ****************************************

// 1.0 Sercio POST - Verifica la Conexion con la blockchain
app.post('/pin_blockchain', (req, res0) => {
    request.post(blockchain_domain+'/api/get_wallets', {
      json: {
       "api_key": api_key,
       "wallet": wallet_nodo
      }
    }, (error, res, body) => {
      if (error) {
        res0.json("Node Configuration Error.");
      }
      console.log(`statusCode: ${res.statusCode}`);
        if(res.statusCode == 200){
          connection = "Connected..."
          res0.json("Master Node Online...");
        }else{
          connection = "Disconnected..."
          res0.json("Master Node Out Line...");
        }


    });
});

// 1.1 Servicio POST Regresa Informacion de configuracion del nodo
app.post('/master_node', (req, res) => {
  res.json({
    identy:ident,
    state:connection,
    user:user_node,
    site:blockchain_domain,
    port:port,
    node_wallet:wallet_nodo,
    currency:cryptocoin
    });
});







// 2.0 Sercio POST - Crea una wallet en blockchain
app.post('/nodo_create_wallet', (req, res0) => {
    request.post(blockchain_domain+'/api/nodo_request_wallet', {
      json: {
       "api_key": api_key,
       "identy": ident
      }
    }, (error, res, body) => {
      if (error) {
        res0.json("Node Configuration Error.");
      }
      console.log(`statusCode: ${res.statusCode}`);
      res0.json(body);
    });
});



// 3.0 Sercio POST - Obtiene La Informacion de Bloques en blockchain
app.post('/nodo_blocks', (req, res0) => {
    request.post(blockchain_domain+'/api/nodo_request_blocks', {
      json: {
       "api_key": api_key,
       "identy": ident
      }
    }, (error, res, body) => {
      if (error) {
        res0.json("Node Configuration Error.");
      }
      console.log(`statusCode: ${res.statusCode}`);
      res0.json(body);
    });
});




// 4.0 Sercio POST - Envia criptomonedas entre dos wallets
app.post('/nodo_send', (req, res0) => {
  const { body: { recipient,amount,wallet }} =  req;

    request.post(blockchain_domain+'/api/service_send', {
      json: {
       "api_key": api_key,
       "identy": ident,
       "wallet": wallet,
       "amount": amount,
       "recipient":recipient,
       "service":"send"
      }
    }, (error, res, body) => {
      if (error) {
        res0.json("Node Configuration Error.");
      }
      console.log(`statusCode: ${res.statusCode}`);
      res0.json(body);
    });
});


// 4.0 Sercio POST - Envia criptomonedas entre dos wallets
app.post('/nodo_get_wallet_info', (req, res0) => {
  const { body: { wallet }} =  req;

    request.post(blockchain_domain+'/api/get_basic_info', {
      json: {
       "api_key": api_key,
       "wallet": wallet
      }
    }, (error, res, body) => {
      if (error) {
        res0.json("Node Configuration Error.");
      }
      console.log(`statusCode: ${res.statusCode}`);
      res0.json(body);
    });
});





// 1.0 Sercio POST - Verifica la Conexion con la blockchain
app.post('/nodo_all_wallets', (req, res0) => {
    request.post(blockchain_domain+'/api/get_wallets', {
      json: {
       "api_key": api_key,
       "wallet": wallet_nodo
      }
    }, (error, res, body) => {
      if (error) {
        res0.json("Node Configuration Error.");
      }
      console.log(`statusCode: ${res.statusCode}`);
        if(res.statusCode == 200){
          connection = "Connected..."
          res0.json(body);
        }else{
          connection = "Disconnected..."
          res0.json("Master Node Out Line...");
        }


    });
});



// 4.0 Sercio POST - Recupera ultimas 20 transacciones
app.post('/nodo_last_transactions', (req, res0) => {
  const { body: { wallet }} =  req;

    request.post(blockchain_domain+'/api/get_last_20_transactions', {
      json: {
       "api_key": api_key,
       "wallet": wallet
      }
    }, (error, res, body) => {
      if (error) {
        res0.json("Node Configuration Error.");
      }
      console.log(`statusCode: ${res.statusCode}`);
      res0.json(body);
    });
});






// ************ LEVANTAMOS SERVIDOR ****************************************
app.listen(HTTP_PORT, () => {
  console.log(`Service HTTP:${HTTP_PORT} listening...`);
  console.log(`Master Node Online on:`);
  console.log(blockchain_domain);
});
